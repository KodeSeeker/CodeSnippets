package com.test.sf;

public enum Degree {
	
	good,
	fair,
	poor,
	not
}
